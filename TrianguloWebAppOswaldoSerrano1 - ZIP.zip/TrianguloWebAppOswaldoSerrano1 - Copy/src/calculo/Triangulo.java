package calculo;

public class Triangulo {
    private double base;
    private double altura;

    // Constructor para inicializar el triángulo con base y altura
    public Triangulo(double base, double altura) {
        this.base = base;   // Inicializa la base
        this.altura = altura; // Inicializa la altura
    }

    // Método para calcular el área del triángulo
    public double calcularArea() {
        return (base * altura) / 2;
    }

    // Método para calcular el perímetro del triángulo
    public double calcularPerimetro() {
        return 3 * base;
    }

    // Métodos getters y setters por si necesitas acceder o modificar los atributos posteriormente
    public double getBase() {
        return base;
    }

    public void setBase(double base) {
        this.base = base;
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }
}
