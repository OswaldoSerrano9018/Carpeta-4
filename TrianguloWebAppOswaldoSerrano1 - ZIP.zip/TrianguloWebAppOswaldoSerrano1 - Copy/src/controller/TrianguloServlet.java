package controller;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/TrianguloServlet")
public class TrianguloServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        double base = Double.parseDouble(request.getParameter("base"));
        double altura = Double.parseDouble(request.getParameter("altura"));

        Triangulo triangulo = new Triangulo(base, altura);
        double area = triangulo.calcularArea();
        double perimetro = triangulo.calcularPerimetro();

        request.setAttribute("base", base);
        request.setAttribute("altura", altura);
        request.setAttribute("area", area);
        request.setAttribute("perimetro", perimetro);

        request.getRequestDispatcher("resultado.jsp").forward(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}
