package imc_app.imc_app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ImcAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
