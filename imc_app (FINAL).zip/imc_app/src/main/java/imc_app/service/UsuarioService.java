package imc_app.service;



import imc_app.model.Usuario;
import imc_app.utils.DatabaseConnection;

import javax.xml.transform.Result;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UsuarioService {

    public Usuario obtenerUsuario(String nombreUsuario) {
        String sql = "SELECT * FROM Usuarios WHERE nombreUsuario = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, nombreUsuario);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Usuario(
                        rs.getString("nombreCompleto"),
                        rs.getString("nombreUsuario"),
                        rs.getInt("edad"),
                        rs.getString("sexo"),
                        rs.getDouble("estatura"),
                        rs.getString("contrasena")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public boolean autenticarUsuario(String nombreUsuario, String contrasena) {
        Usuario usuario = obtenerUsuario(nombreUsuario);
        return usuario != null && usuario.getContrasena().equals(contrasena);
    }

    public void registrarUsuario(Usuario usuario) {
        String sql = "INSERT INTO Usuarios (nombreCompleto, nombreUsuario, edad, sexo, estatura, contrasena, fechaRegistro, peso) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, usuario.getNombreCompleto());
            stmt.setString(2, usuario.getNombreUsuario());
            stmt.setInt(3, usuario.getEdad());
            stmt.setString(4, usuario.getSexo());
            stmt.setDouble(5, usuario.getEstatura());
            stmt.setString(6, usuario.getContrasena());
            stmt.setDate(7, new java.sql.Date(System.currentTimeMillis()));
            stmt.setDouble(8, usuario.getPeso());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public double leerIMC(String nombreUsuario){


        String sql = "SELECT estatura, peso FROM Usuarios WHERE nombreUsuario = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, nombreUsuario);

            ResultSet resulset = stmt.executeQuery();

            resulset.next();

            double estatura = resulset.getDouble("estatura");
            double peso = resulset.getDouble("peso");

            return peso / (estatura*estatura);


        } catch (SQLException e) {
            e.printStackTrace();
            return 0.0;
        }


    }

}