package imc_app.controller;


import imc_app.model.Usuario;
import imc_app.service.UsuarioService;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.io.IOException;

@Controller
@RequestMapping("/registro")
public class RegistroController {

    private UsuarioService usuarioService = new UsuarioService();

    @PostMapping
    protected String doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String nombreCompleto = request.getParameter("nombreCompleto");
        String nombreUsuario = request.getParameter("nombreUsuario");
        int edad = Integer.parseInt(request.getParameter("edad"));
        String sexo = request.getParameter("sexo");
        double estatura = Double.parseDouble(request.getParameter("estatura"));
        String contrasena = request.getParameter("contrasena");
        double peso = Double.parseDouble(request.getParameter("peso"));

        if (estatura < 1.0 || estatura > 2.5 || edad < 15) {
            return "error";
        } else {
            Usuario usuario = new Usuario(nombreCompleto, nombreUsuario, edad, sexo, estatura, contrasena);
            usuario.setPeso(peso);
            usuarioService.registrarUsuario(usuario);
            return "login";
        }
    }

    @GetMapping({"", "/"})
    public String form(){
        return "registro";
    }
}