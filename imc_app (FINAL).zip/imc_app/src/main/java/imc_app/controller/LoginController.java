package imc_app.controller;


import imc_app.service.UsuarioService;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.io.IOException;

@Controller
@RequestMapping("/login")
public class LoginController {
    private static final long serialVersionUID = 1L;
    private UsuarioService usuarioService = new UsuarioService();

    @PostMapping
    public String doPost(HttpServletRequest request, Model model) throws ServletException, IOException {
        String nombreUsuario = request.getParameter("nombreUsuario");
        String contrasena = request.getParameter("contrasena");

        if (usuarioService.autenticarUsuario(nombreUsuario, contrasena)) {
            HttpSession session = request.getSession();
            session.setAttribute("nombreUsuario", nombreUsuario);

            model.addAttribute("imc", usuarioService.leerIMC(nombreUsuario));

            return "bienvenido";
        } else {
            return "error";
        }
    }

    @GetMapping({"", "/"})
    public String doGet(){
        return "login";
    }
}